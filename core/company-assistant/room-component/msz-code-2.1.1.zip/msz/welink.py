"""welink-cli 封装（会后动作用；找不到时会后动作自动不可用，不影响抢订）。

子命令与旧版一致：
  im send-to-user --receiver <ID> --text <内容>
  meeting list --limit 100
  meeting query-list --page 1 --size 50 --meeting-start-time <ms> --meeting-end-time <ms> --type 3 --meeting-sort asc
  meeting cancel --meeting-id <ID>
"""
import json
import os
import re
import shutil
import subprocess
from datetime import datetime, timedelta

CREATE_NO_WINDOW = 0x08000000


def find_cli(override=""):
    if override and os.path.exists(override):
        return override
    appdata = os.environ.get("APPDATA", "")
    for p in (
        os.path.join(appdata, "npm", "welink-cli.cmd"),
        os.path.join(appdata, "npm", "welink-cli"),
        os.path.join(appdata, "npm", "node_modules", "@welink", "welink-cli", "welink-cli.exe"),
    ):
        if os.path.exists(p):
            return p
    return shutil.which("welink-cli")


def _safe(text):
    # .cmd 由 cmd.exe 解释，这几个符号会被当成命令语法，换成全角
    return str(text).translate(str.maketrans({"&": "＆", "|": "｜", "<": "＜", ">": "＞", "^": "＾", "%": "％", '"': "”"}))


def run(args, override="", timeout=60):
    cli = find_cli(override)
    if not cli:
        raise RuntimeError("没找到 welink-cli")
    p = subprocess.run(
        [cli] + [_safe(a) for a in args],
        capture_output=True,
        timeout=timeout,
        creationflags=CREATE_NO_WINDOW,
    )
    out = (p.stdout or b"").decode("utf-8", "replace")
    err = (p.stderr or b"").decode("utf-8", "replace")
    if p.returncode != 0:
        raise RuntimeError(f"welink-cli 返回 {p.returncode}：{(err or out).strip()[:200]}")
    return out


def send(receiver, text, override=""):
    return run(["im", "send-to-user", "--receiver", receiver, "--text", text], override)


# ---------- 查找会议 ----------
_ID_KEYS = ("meetingId", "meetingID", "meeting_id", "confId", "conferenceId", "id")
_SUBJ_KEYS = ("subject", "meetingSubject", "topic", "meetingTopic", "title", "name", "主题")
_TIME_KEYS = ("startTime", "meetingStartTime", "start_time", "beginTime", "start", "meetingStart")


def _parse_json(text):
    text = text.strip()
    i = min([x for x in (text.find("{"), text.find("[")) if x >= 0], default=-1)
    if i < 0:
        return None
    try:
        return json.loads(text[i:])
    except Exception:
        return None


def _dicts(o):
    if isinstance(o, dict):
        yield o
        for v in o.values():
            yield from _dicts(v)
    elif isinstance(o, list):
        for v in o:
            yield from _dicts(v)


def _to_dt(v):
    if v is None:
        return None
    if isinstance(v, (int, float)) or (isinstance(v, str) and v.isdigit()):
        n = float(v)
        return datetime.fromtimestamp(n / 1000 if n > 1e11 else n)
    s = str(v).strip().replace("T", " ").replace("/", "-")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(s[:19] if fmt.endswith("%S") else s[:16], fmt)
        except ValueError:
            pass
    return None


def _match(o, topic, start_dt):
    subj = next((o[k] for k in _SUBJ_KEYS if k in o), None)
    mid = next((o[k] for k in _ID_KEYS if k in o and o[k]), None)
    if subj is None or mid is None or str(subj).strip() != topic.strip():
        return None
    t = next((_to_dt(o[k]) for k in _TIME_KEYS if k in o), None)
    if t is not None:
        if abs((t - start_dt).total_seconds()) > 60:
            return None
    elif start_dt.strftime("%Y-%m-%d") not in json.dumps(o, ensure_ascii=False) and start_dt.strftime("%Y/%m/%d") not in json.dumps(o, ensure_ascii=False):
        return None
    return str(mid)


def find_meeting(topic, start_dt, end_dt, override=""):
    """先查会议列表，找不到再按时间范围查“我预定的”。返回 meetingId 或 None。"""
    for args in (
        ["meeting", "list", "--limit", "100"],
        ["meeting", "query-list", "--page", "1", "--size", "50",
         "--meeting-start-time", str(int((start_dt - timedelta(minutes=1)).timestamp() * 1000)),
         "--meeting-end-time", str(int((end_dt + timedelta(minutes=1)).timestamp() * 1000)),
         "--type", "3", "--meeting-sort", "asc"],
    ):
        try:
            data = _parse_json(run(args, override))
        except Exception:
            continue
        for o in _dicts(data):
            mid = _match(o, topic, start_dt)
            if mid:
                return mid
    return None


def cancel(meeting_id, override=""):
    return run(["meeting", "cancel", "--meeting-id", meeting_id], override)
