"""程序入口（由启动器 app.py 调用，随代码更新一起换）。

双击启动界面；--daemon 启动后直接进入守护并收到托盘；--selftest 不开界面，只验证能调起浏览器。
"""
import getpass
import json
import os
import sys

from .qtfix import fix_plugin_path

fix_plugin_path()

from PyQt5.QtCore import Qt, QTimer  # noqa: E402
from PyQt5.QtNetwork import QLocalServer, QLocalSocket  # noqa: E402
from PyQt5.QtWidgets import QApplication  # noqa: E402


def selftest():
    """秘书终结者.exe --selftest：不开界面，验证能调起浏览器，结果写到 selftest.txt。"""
    import time
    from . import config as C
    from . import update

    lines = [f"秘书终结者 v{C.VERSION} 自检 {time.strftime('%Y-%m-%d %H:%M:%S')}",
             f"程序代码：{update.code_origin()}；exe v{update.exe_version()}，运行环境 {update.exe_shell()}",
             f"数据目录：{C.app_dir()}"]
    ok = False
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            for ch in ("msedge", "chrome"):
                try:
                    b = p.chromium.launch(channel=ch, headless=True)
                    pg = b.new_page()
                    pg.set_content("<p id=x>ok</p>")
                    lines.append(f"{ch}：可用，页面脚本返回 {pg.inner_text('#x')}")
                    b.close()
                    ok = True
                    break
                except Exception as e:
                    lines.append(f"{ch}：不可用（{str(e).splitlines()[0][:120]}）")
    except Exception as e:
        lines.append(f"Playwright 加载失败：{e}")
    lines.append("结论：通过" if ok else "结论：失败")
    with open(C.path("selftest.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return 0 if ok else 1


def _arg(name):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None


def _e2e_report(w):
    """测试钩子：MSZ_E2E_REPORT=文件 时把版本信息写出去；MSZ_E2E_EXIT=1 时写完就退出。"""
    path = os.environ.get("MSZ_E2E_REPORT")
    if not path:
        return
    if os.environ.get("MSZ_E2E_UPDATE") == "1" and not _arg("--updated-from"):
        return  # 更新测试里第一个进程负责点按钮，由重启后的新进程来报告
    from . import config as C
    from . import update

    data = {"version": C.VERSION, "exe_version": update.exe_version(), "exe_shell": update.exe_shell(),
            "code": update.code_origin(), "argv": sys.argv[1:], "pid": os.getpid(),
            "exe": sys.executable, "sidebar": w.upd_btn.text()}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    if os.environ.get("MSZ_E2E_EXIT") == "1":
        QTimer.singleShot(int(os.environ.get("MSZ_E2E_EXIT_DELAY", "300")), w.quit_app)


def main():
    if "--selftest" in sys.argv:
        return selftest()
    from . import update

    out = _arg("--version-json")
    if out:  # 发布工具用来确认 exe 的版本；不开界面
        from . import config as C
        with open(out, "w", encoding="utf-8") as f:
            json.dump({"version": C.VERSION, "exe_version": update.exe_version(), "exe_shell": update.exe_shell(),
                       "code": update.code_origin()}, f, ensure_ascii=False)
        return 0

    update.cleanup_after_swap()
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication.instance() or QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)

    # 只允许一个实例：两个实例会抢同一个浏览器登录资料夹
    key = os.environ.get("MSZ_HUB_TEST_INSTANCE") or f"MishuTerminator-{getpass.getuser()}"
    sock = QLocalSocket()
    sock.connectToServer(key)
    if sock.waitForConnected(300):
        sock.write(b"hub" if "--hub-control" in sys.argv else b"show")
        sock.waitForBytesWritten(300)
        return 0
    QLocalServer.removeServer(key)
    server = QLocalServer()
    server.listen(key)

    from .gui import MainWindow, apply_theme

    apply_theme(app)
    daemon = "--daemon" in sys.argv
    hub_control = "--hub-control" in sys.argv
    w = MainWindow(start_daemon=daemon, updated_from=_arg("--updated-from"))

    def on_conn():
        c = server.nextPendingConnection()
        if c:
            def receive():
                message = bytes(c.readAll())
                if message == b"hub":
                    from .hub_control import attach
                    attach(w)
                else:
                    w.show_window()
                c.disconnectFromServer()
            c.readyRead.connect(receive)
            if c.bytesAvailable():
                receive()

    server.newConnection.connect(on_conn)
    if hub_control:
        from .hub_control import attach
        attach(w)
    if not daemon and not hub_control:
        w.show()
    QTimer.singleShot(4000, lambda: _e2e_report(w))  # 晚于 3 秒的「正常运行」确认
    return app.exec_()
