"""在线更新的界面：后台检查/下载线程、提醒节奏、更新弹窗、侧栏入口。

照 PPT Doctor v2.0.3（update_ui.py / update_dialog.py）与 AI Hub 公司版的做法移植到 PyQt5：
- 启动后后台查；发现新版本时同一版本只自动弹一次窗，之后侧栏「软件更新」挂红点，点开算已读；
- 弹窗显示 当前版本 → 新版本、代码更新还是整包与大小、更新说明；下载时显示正在用哪个源、
  进度、速度、剩余时间，以及每个源的结果（成功 / 失败 + 人话原因）；
- 「立即重启」要等新进程回执才退出；开抢前后、正在抢订时不重启，说明原因。
"""
import json
import os
import sys
import threading
from datetime import datetime

from PyQt5.QtCore import QObject, Qt, QThread, QTimer, QUrl, pyqtSignal
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtWidgets import (
    QDialog, QFrame, QHBoxLayout, QLabel, QLayout, QProgressBar, QPushButton, QVBoxLayout, QWidget,
)

from . import config as C
from . import netfetch, update

ACC, INK, INK2, MUTE, FAINT, LINE = "#3478f6", "#1c1c1e", "#2c2c30", "#6c6c72", "#9a9aa0", "#e4e4ea"
CHECK_EVERY_MS = 6 * 3600 * 1000

DIALOG_QSS = f"""
QDialog {{ background: #ffffff; }}
QLabel#auTitle {{ font-size: 16px; font-weight: 700; color: {INK}; }}
QLabel#auSub {{ font-size: 12px; color: {FAINT}; }}
QFrame#auVersions {{ background: #f3f3f6; border: none; border-radius: 10px; }}
QLabel#auVerSmall {{ font-size: 11px; color: {FAINT}; }}
QLabel#auVerBig {{ font-size: 18px; font-weight: 700; color: {INK}; }}
QLabel#auArrow {{ font-size: 18px; color: {ACC}; }}
QLabel#auPlan {{ font-size: 12px; color: {MUTE}; }}
QLabel#auSection {{ font-size: 12px; font-weight: 700; color: {MUTE}; }}
QLabel#auNotes {{ font-size: 13px; color: {INK2}; }}
QLabel#auMsg {{ border-radius: 10px; padding: 9px 12px; font-size: 13px; }}
QLabel#auMsg[kind="ok"] {{ background: #effaf3; color: #15803d; }}
QLabel#auMsg[kind="bad"] {{ background: #fdecea; color: #c2362b; }}
QLabel#auMsg[kind="info"] {{ background: #f3f3f6; color: {INK2}; }}
QLabel#auMsg[kind="warn"] {{ background: #fdf3e7; color: #b45309; }}
QProgressBar#auProgress {{ background: #ececf0; border: none; border-radius: 4px; min-height: 8px; max-height: 8px; }}
QProgressBar#auProgress::chunk {{ background: {ACC}; border-radius: 4px; }}
QLabel#auMeta {{ font-size: 12px; color: {MUTE}; }}
QFrame#auSources {{ background: transparent; border: 1px solid {LINE}; border-radius: 10px; }}
QLabel#auSrcName {{ font-size: 12px; font-weight: 700; color: {INK}; }}
QLabel#auSrcText {{ font-size: 12px; color: {MUTE}; }}
QLabel#auSrcText[st="ok"] {{ color: #15803d; }}
QLabel#auSrcText[st="failed"] {{ color: #c2362b; }}
QLabel#auSrcText[st="downloading"] {{ color: {ACC}; }}
QFrame#auSrcSep {{ background: {LINE}; border: none; max-height: 1px; min-height: 1px; }}
"""


def _repolish(w):
    w.style().unpolish(w)
    w.style().polish(w)


# ---------- 提醒状态（只弹一次 / 已读）存在 updates/ui-state.json ----------
def _state_path():
    return update.updates_dir("ui-state.json")


def _read_state():
    try:
        with open(_state_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _write_state(**kw):
    s = _read_state()
    s.update(kw)
    try:
        os.makedirs(update.updates_dir(), exist_ok=True)
        with open(_state_path(), "w", encoding="utf-8") as f:
            json.dump(s, f, ensure_ascii=False)
    except OSError:
        pass


# ---------- 线程 ----------
class _Cancelable:
    def _init_cancel(self):
        self._cancel = False
        self._lock = threading.Lock()
        self._resp = None

    def _set_resp(self, r):
        with self._lock:
            self._resp = r

    def stop(self):
        self._cancel = True
        with self._lock:
            r, self._resp = self._resp, None
        if r is not None:
            try:
                r.close()
            except Exception:  # noqa: BLE001
                pass


class CheckThread(QThread, _Cancelable):
    reported = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_cancel()

    def run(self):
        try:
            rep = update.check(timeout=8.0, response_callback=self._set_resp)
        except Exception as e:  # noqa: BLE001
            rep = update.CheckReport(best=None, checks=[], error=f"检查更新出错：{e}")
        if not self._cancel:
            self.reported.emit(rep)


class DownloadThread(QThread, _Cancelable):
    status = pyqtSignal(object)
    attempts = pyqtSignal(object)
    done = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, info, parent=None):
        super().__init__(parent)
        self._init_cancel()
        self.info = info

    def run(self):
        try:
            path = update.download(self.info, cancel=lambda: self._cancel, on_status=self.status.emit,
                                   on_attempts=self.attempts.emit, response_callback=self._set_resp)
            if not self._cancel:
                self.done.emit(path)
        except InterruptedError:
            pass
        except Exception as e:  # noqa: BLE001
            if not self._cancel:
                self.failed.emit(str(e))


# ---------- 控制器 ----------
class UpdateController(QObject):
    """检查 → 弹窗/红点 → 下载（逐源回落）→ 就绪 → 重启。win 是主窗口（读守护状态、退出）。"""

    state_changed = pyqtSignal()

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.state = "idle"          # idle / checking / available / downloading / ready / applying / error
        self.check_status = "never"  # never / none / failed
        self.report = None
        self.info = None
        self.path = ""
        self.status = {}
        self.attempts = []
        self.error = ""
        self.notice = ""             # 不能重启的原因等提示
        self.manual = False
        self.dialog = None
        self._th = None
        self.timer = QTimer(self, interval=CHECK_EVERY_MS, timeout=self.auto_check)
        if os.environ.get("MSZ_E2E_UPDATE") == "1" and "--updated-from" not in sys.argv:
            self.state_changed.connect(self._e2e_drive)

    # ----- 查询 -----
    def phase(self):
        if self.state == "idle":
            return {"none": "none", "failed": "error"}.get(self.check_status, "idle")
        return self.state

    def pending_version(self):
        if self.info is not None and self.state in ("available", "downloading", "ready", "error", "applying"):
            return self.info.version
        return ""

    def is_unread(self):
        v = self.pending_version()
        return bool(v) and _read_state().get("seen") != v

    def _mark_seen(self):
        v = self.pending_version()
        if v:
            _write_state(seen=v, prompted=v)
        self.state_changed.emit()

    # ----- 检查 -----
    def auto_check(self):
        if self.win.cfg["系统"].get("自动检查更新", True):
            self.start_check(manual=False)

    def start_check(self, manual=True):
        if self.state not in ("idle",):
            self.state_changed.emit()
            return
        self.manual = manual
        self.state = "checking"
        self.error = ""
        self._th = CheckThread(self)
        self._th.reported.connect(self._on_report)
        self._th.start()
        self.state_changed.emit()

    def _on_report(self, rep):
        if self.state != "checking":
            return
        self.report = rep
        for c in rep.checks:
            if not c.ok:
                self.win.log(f"更新源「{c.name}」不可用：{c.reason}", "warn")
        if rep.best is not None:
            self.info = rep.best
            self.state = "available"
            self.win.log(f"发现新版本 v{rep.best.version}（{'程序代码更新' if rep.best.kind == 'code' else '完整程序更新'}）", "ok")
        else:
            self.state = "idle"
            self.check_status = "failed" if rep.all_failed or (rep.error and not rep.checks) else "none"
            self.error = rep.error
            if rep.error:
                if self.manual:
                    self.win.log(rep.error, "warn")
            else:
                self.win.log(f"检查更新：已是最新版本 v{C.VERSION}")
        self.state_changed.emit()
        self._maybe_prompt_once()

    def _maybe_prompt_once(self):
        v = self.pending_version()
        if not v or self.state != "available":
            return
        if self.manual:
            if self.dialog is not None and self.dialog.isVisible():
                self._mark_seen()
            return
        if _read_state().get("prompted") == v:
            return
        if not self.win.isVisible():
            return  # 在托盘里：等用户打开主窗口后从侧栏红点看到
        _write_state(prompted=v)
        self.open_dialog(mark_seen=False)

    # ----- 弹窗 -----
    def open_dialog(self, mark_seen=True):
        if self.dialog is None:
            self.dialog = UpdateDialog(self, self.win)
        if mark_seen:
            self._mark_seen()
        if self.state == "idle":
            self.start_check(manual=True)
        self.dialog.refresh()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    # ----- 下载 -----
    def start_download(self):
        if self.info is None:
            return
        self._mark_seen()
        self.state = "downloading"
        self.status, self.attempts, self.error, self.notice = {}, [], "", ""
        self._th = DownloadThread(self.info, self)
        self._th.status.connect(self._on_status)
        self._th.attempts.connect(self._on_attempts)
        self._th.done.connect(self._on_done)
        self._th.failed.connect(self._on_failed)
        self._th.start()
        self.state_changed.emit()

    def cancel_download(self):
        if self.state == "downloading" and self._th is not None:
            self._th.stop()
            self.state = "available"
            self.status = {}
            self.attempts = [dict(a, status="cancelled", reason="已取消") if a.get("status") == "downloading" else a
                             for a in self.attempts]
            self.state_changed.emit()

    def _on_status(self, st):
        if self.state == "downloading":
            self.status = dict(st or {})
            self.state_changed.emit()

    def _on_attempts(self, at):
        if self.state == "downloading":
            self.attempts = [dict(a) for a in at or []]
            self.state_changed.emit()

    def _on_done(self, path):
        if self.state != "downloading":
            return
        self.path = path
        self.state = "ready"
        for a in self.attempts:
            if a.get("status") == "failed":
                self.win.log(f"从「{a.get('name')}」下载失败：{a.get('reason')}，已换下一个源", "warn")
        self.win.log(f"新版本 v{self.info.version} 已从「{self.info.used_source}」下载并校验通过，重启后生效", "ok")
        self.state_changed.emit()

    def _on_failed(self, msg):
        if self.state != "downloading":
            return
        self.state = "error"
        self.error = msg.replace("AllSourcesFailed: ", "")
        self.win.log(f"下载更新失败：{self.error}", "warn")
        self.state_changed.emit()

    # ----- 重启 -----
    def apply(self):
        if self.state != "ready":
            return
        w = self.win
        why = update.blocked_reason(datetime.now(), w.next_open if w.job == "daemon" else None,
                                    w.job if w._busy() else None)
        if why:
            self.notice = why
            self.win.log(f"现在不重启：{why}", "warn")
            self.state_changed.emit()
            return
        self.state = "applying"
        self.notice = ""
        self.state_changed.emit()
        from PyQt5.QtWidgets import QApplication
        QApplication.processEvents()
        args = ["--daemon"] if w.job == "daemon" else []
        old = None
        try:
            if self.info.kind == "code":
                update.install_code(self.info, self.path)
            else:
                old = update.swap_exe(self.path)
            ok = update.restart(args)
        except Exception as e:  # noqa: BLE001
            ok, err = False, str(e)
        else:
            err = "新程序 20 秒内没有启动"
        if ok:
            w.log(f"新程序已启动，本程序退出（v{C.VERSION} → v{self.info.version}）", "ok")
            w.quit_app()
            return
        if old:
            try:
                update.undo_swap(old)
            except Exception as e:  # noqa: BLE001
                err += f"；恢复旧程序也失败：{e}"
        self.state = "error"
        tail = "新代码已装好，下次手动打开程序时生效。" if self.info.kind == "code" else "已恢复原来的程序。"
        self.error = f"重启没成功：{err}。程序没有关闭，{tail}可以点「重试」，或到发布页手动下载。"
        w.log(self.error, "bad")
        self.state_changed.emit()

    def retry(self):
        if self.state == "error" and self.path and os.path.exists(self.path):
            self.state = "ready"
            self.apply()
        elif self.state == "error" and self.info is not None:
            self.start_download()
        else:
            self.state, self.check_status = "idle", "never"
            self.start_check(manual=True)

    def shutdown(self):
        if self._th is not None and self._th.isRunning():
            self._th.stop()
            self._th.wait(3000)

    # ----- 测试钩子：MSZ_E2E_UPDATE=1 时自动点弹窗里的按钮，走真实的界面路径 -----
    def _e2e_drive(self):
        ph = self.phase()
        if ph == "available" and (self.dialog is None or not self.dialog.isVisible()):
            QTimer.singleShot(200, lambda: self.open_dialog())
            return
        if ph in ("available", "ready") and not self.notice and self.dialog is not None and self.dialog.isVisible():
            QTimer.singleShot(400, lambda p=ph: self.phase() == p and self.dialog.btn_primary.click())

    # ----- 侧栏入口文字 -----
    def entry_text(self):
        ph = self.phase()
        if ph == "downloading":
            st = self.status
            pct = int(st.get("received", 0) * 100 / st["total"]) if st.get("total") else 0
            return f"下载更新 {pct}%"
        if ph == "ready":
            return "更新已就绪 · 点此重启"
        if self.pending_version():
            return f"有新版本 v{self.pending_version()}"
        if ph == "checking":
            return "正在检查更新…"
        return f"软件更新 · v{C.VERSION}"


# ---------- 弹窗 ----------
class SourceList(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("auSources")
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(0, 2, 0, 2)
        self._lay.setSpacing(0)
        self.rows = []

    def set_rows(self, rows):
        self.rows = list(rows)
        while self._lay.count():
            w = self._lay.takeAt(0).widget()
            if w is not None:
                w.hide()
                w.setParent(None)
                w.deleteLater()
        for i, (name, st, text) in enumerate(self.rows):
            if i:
                sep = QFrame()
                sep.setObjectName("auSrcSep")
                self._lay.addWidget(sep)
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(12, 7, 12, 7)
            rl.setSpacing(10)
            n = QLabel(name)
            n.setObjectName("auSrcName")
            n.setFixedWidth(78)
            t = QLabel(text)
            t.setObjectName("auSrcText")
            t.setProperty("st", st)
            t.setWordWrap(True)
            t.setTextInteractionFlags(Qt.TextSelectableByMouse)
            rl.addWidget(n, 0, Qt.AlignTop)
            rl.addWidget(t, 1)
            self._lay.addWidget(row)
        self.setVisible(bool(self.rows))


def attempt_rows(attempts, names, downloading):
    by = {a.get("name"): a for a in attempts or []}
    names = list(names or [])
    for a in attempts or []:
        if a.get("name") not in names:
            names.append(a.get("name"))
    rows = []
    for name in names:
        a = by.get(name)
        if a is None:
            rows.append((name, "idle", "排队中（前一个源失败才会用）" if downloading else "未使用"))
            continue
        st = a.get("status", "")
        if st == "ok":
            text = f"下载完成并校验通过 · {netfetch.fmt_bytes(a.get('bytes', 0))} · {a.get('ms', 0) / 1000:.1f} 秒"
        elif st == "downloading":
            text = "正在下载…"
        elif st == "cancelled":
            text = "已取消"
        else:
            text = f"失败：{a.get('reason') or '原因未知'}"
        rows.append((name, st, text))
    return rows


def check_rows(checks):
    return [(c.name, "ok" if c.ok else "failed",
             f"可用，最新 v{c.version} · {c.ms / 1000:.1f} 秒" if c.ok else f"连不上：{c.reason or '原因未知'}")
            for c in checks or []]


class UpdateDialog(QDialog):
    def __init__(self, ctl, parent=None):
        super().__init__(parent)
        self.ctl = ctl
        self.setWindowTitle(f"软件更新 · {C.APP_NAME}")
        self.setModal(False)
        self.setStyleSheet(DIALOG_QSS)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 22, 18)
        lay.setSpacing(10)

        head = QHBoxLayout()
        head.setSpacing(12)
        icon = QLabel()
        if parent is not None:
            icon.setPixmap(parent.windowIcon().pixmap(36, 36))
        icon.setFixedSize(36, 36)
        head.addWidget(icon)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        t = QLabel("软件更新")
        t.setObjectName("auTitle")
        self.sub = QLabel("")
        self.sub.setObjectName("auSub")
        titles.addWidget(t)
        titles.addWidget(self.sub)
        head.addLayout(titles, 1)
        lay.addLayout(head)

        self.versions = QFrame()
        self.versions.setObjectName("auVersions")
        vl = QHBoxLayout(self.versions)
        vl.setContentsMargins(14, 10, 14, 10)
        vl.setSpacing(12)
        self.cur_box, self.cur_ver = self._ver_block("当前版本")
        self.arrow = QLabel("→")
        self.arrow.setObjectName("auArrow")
        self.new_box, self.new_ver = self._ver_block("新版本")
        self.plan = QLabel("")
        self.plan.setObjectName("auPlan")
        self.plan.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.plan.setWordWrap(True)
        for w in (self.cur_box, self.arrow, self.new_box):
            vl.addWidget(w)
        vl.addWidget(self.plan, 1)
        self.versions.setMinimumWidth(516)  # 各状态宽度一致
        lay.addWidget(self.versions)

        self.msg = QLabel("")
        self.msg.setObjectName("auMsg")
        self.msg.setWordWrap(True)
        self.msg.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lay.addWidget(self.msg)

        self.notes_head = QLabel("本次更新")
        self.notes_head.setObjectName("auSection")
        self.notes = QLabel("")
        self.notes.setObjectName("auNotes")
        self.notes.setWordWrap(True)
        lay.addWidget(self.notes_head)
        lay.addWidget(self.notes)

        self.dl_head = QLabel("")
        self.dl_head.setObjectName("auSection")
        lay.addWidget(self.dl_head)
        self.progress = QProgressBar()
        self.progress.setObjectName("auProgress")
        self.progress.setRange(0, 1000)
        self.progress.setTextVisible(False)
        lay.addWidget(self.progress)
        self.meta_row = QWidget()
        meta = QHBoxLayout(self.meta_row)
        meta.setContentsMargins(0, 0, 0, 0)
        self.meta_left = QLabel("")
        self.meta_left.setObjectName("auMeta")
        self.meta_right = QLabel("")
        self.meta_right.setObjectName("auMeta")
        meta.addWidget(self.meta_left, 1)
        meta.addWidget(self.meta_right, 0, Qt.AlignRight)
        lay.addWidget(self.meta_row)

        self.src_head = QLabel("")
        self.src_head.setObjectName("auSection")
        lay.addWidget(self.src_head)
        self.sources = SourceList()
        lay.addWidget(self.sources)

        foot = QHBoxLayout()
        foot.setSpacing(8)
        foot.addStretch(1)
        self.btn_manual = self._btn("打开发布页手动下载", lambda: QDesktopServices.openUrl(QUrl(update.RELEASE_PAGE)))
        self.btn_close = self._btn("稍后", self.close)
        self.btn_cancel = self._btn("取消下载", self.ctl.cancel_download)
        self.btn_primary = self._btn("下载更新", self._on_primary, primary=True)
        for b in (self.btn_manual, self.btn_close, self.btn_cancel, self.btn_primary):
            foot.addWidget(b)
        lay.addSpacing(4)
        lay.addLayout(foot)
        self.setFixedWidth(560)
        lay.setSizeConstraint(QLayout.SetFixedSize)
        self.ctl.state_changed.connect(self.refresh)
        self.refresh()

    def _ver_block(self, text):
        box = QWidget()
        bl = QVBoxLayout(box)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(0)
        small = QLabel(text)
        small.setObjectName("auVerSmall")
        big = QLabel("")
        big.setObjectName("auVerBig")
        bl.addWidget(small)
        bl.addWidget(big)
        return box, big

    def _btn(self, text, slot, primary=False):
        b = QPushButton(text)
        if primary:
            b.setObjectName("Primary")
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(slot)
        return b

    def _set_msg(self, text, kind):
        self.msg.setText(text)
        self.msg.setProperty("kind", kind)
        _repolish(self.msg)
        self.msg.setVisible(bool(text))

    def _on_primary(self):
        ph = self.ctl.phase()
        if ph == "available":
            self.ctl.start_download()
        elif ph == "ready":
            self.ctl.apply()
        elif ph == "error":
            self.ctl.retry()
        else:
            self.ctl.state, self.ctl.check_status = "idle", "never"
            self.ctl.start_check(manual=True)

    def refresh(self):
        c = self.ctl
        ph = c.phase()
        info = c.info
        self.sub.setText(f"{C.APP_NAME} · 程序代码：{update.code_origin()} · exe v{update.exe_version()}")
        self.cur_ver.setText(f"v{C.VERSION}")
        has_new = info is not None and ph in ("available", "downloading", "ready", "applying", "error")
        for w in (self.arrow, self.new_box, self.plan):
            w.setVisible(has_new)
        if has_new:
            self.new_ver.setText(f"v{info.version}")
            if info.kind == "code":
                self.plan.setText(f"<b>程序代码更新 · {netfetch.fmt_bytes(info.size)}</b><br>只换程序代码")
            else:
                self.plan.setText(f"<b>完整程序 · {netfetch.fmt_bytes(info.size)}</b><br>运行环境有变化，换整个程序")

        notes = [str(n).strip(" -•\t") for n in (info.notes if info else []) if str(n).strip()]
        show_notes = ph == "available" and bool(notes)
        self.notes_head.setVisible(show_notes)
        self.notes.setVisible(show_notes)
        self.notes.setText("\n".join("· " + n for n in notes[:12]))

        downloading = ph == "downloading"
        for w in (self.dl_head, self.progress, self.meta_row):
            w.setVisible(downloading)
        if downloading:
            st = c.status
            cur = st.get("source") or next((a.get("name") for a in c.attempts if a.get("status") == "downloading"), "…")
            self.dl_head.setText(f"正在从「{cur}」下载")
            total = st.get("total") or info.size
            got = st.get("received", 0)
            self.progress.setValue(int(min(1.0, got / total) * 1000) if total else 0)
            speed = f" · {netfetch.fmt_bytes(st['speed'])}/s" if st.get("speed") else ""
            self.meta_left.setText(f"{netfetch.fmt_bytes(got)} / {netfetch.fmt_bytes(total)}{speed}")
            self.meta_right.setText(netfetch.fmt_eta(st.get("eta")).replace("剩约", "剩余约"))

        rows, src_title = [], ""
        checks = c.report.checks if c.report else []
        if ph == "none":
            self._set_msg(f"已是最新版本 v{C.VERSION}。", "ok")
            rows, src_title = check_rows(checks), "更新源"
        elif ph == "checking":
            self._set_msg("正在向各个更新源查询最新版本…", "info")
        elif ph == "available":
            self._set_msg("", "info")
            rows = attempt_rows(c.attempts, info.source_names, False) if c.attempts else check_rows(checks)
            src_title = "更新源（按顺序尝试，失败自动换下一个）"
        elif downloading:
            self._set_msg("", "info")
            rows = attempt_rows(c.attempts, info.source_names, True)
        elif ph == "ready":
            if c.notice:
                self._set_msg(f"现在不重启：{c.notice}。新版本已下载好，到时再点「立即重启」。", "warn")
            else:
                restart_note = "，守护会自动接着运行" if self.ctl.win.job == "daemon" else ""
                self._set_msg(f"新版本已从「{info.used_source or '更新源'}」下载并校验通过。点「立即重启」后几秒内自动重新打开{restart_note}；"
                              "登录资料、配置和历史都不受影响。", "ok")
            rows = attempt_rows(c.attempts, info.source_names, False)
        elif ph == "applying":
            self._set_msg("正在启动新程序；确认它起来后，本程序会自动关闭…", "info")
        elif ph == "error":
            err = c.error or "更新失败"
            if err.startswith("所有更新源都连不上") and checks:
                err = "所有更新源都连不上，各源原因见下方。可以稍后点「重试」，或打开发布页手动下载。"
            self._set_msg(err, "bad")
            if c.attempts:
                rows, src_title = attempt_rows(c.attempts, info.source_names if info else [], False), "各下载源的结果"
            else:
                rows, src_title = check_rows(checks), "更新源"
        else:
            self._set_msg("点「检查更新」查询最新版本。", "info")
        self.src_head.setText(src_title)
        self.src_head.setVisible(bool(src_title) and bool(rows))
        self.sources.set_rows(rows)

        primary = {"available": "下载更新", "ready": "立即重启", "none": "重新检查", "idle": "检查更新",
                   "error": "重试"}.get(ph, "")
        self.btn_primary.setText(primary)
        self.btn_primary.setVisible(bool(primary))
        self.btn_cancel.setVisible(downloading)
        self.btn_manual.setVisible(ph == "error")
        self.btn_close.setText({"none": "好的", "ready": "稍后", "available": "稍后"}.get(ph, "关闭"))
        self.btn_close.setVisible(ph != "applying")
        self.adjustSize()
