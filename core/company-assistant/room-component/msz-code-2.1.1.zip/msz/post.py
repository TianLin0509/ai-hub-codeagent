"""会后动作：抢到后排进 pending_actions.json，到点执行。

旧版放在内存线程里，程序一关就丢；这里落盘，重启后接着做。
"""
import json
import os
import threading
import uuid
from datetime import datetime, timedelta

from . import config as C
from . import welink

_lock = threading.Lock()
FILE = "pending_actions.json"


def _load():
    p = C.path(FILE)
    if not os.path.exists(p):
        return []
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save(items):
    p = C.path(FILE)
    with open(p + ".tmp", "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)
    os.replace(p + ".tmp", p)


def pending():
    with _lock:
        return sorted(_load(), key=lambda a: a["due"])


def schedule_for(cfg, res):
    """根据抢订结果和会后动作设置，排入待办。返回新排入的条数。"""
    if res.get("status") != "成功" or res.get("test"):
        return 0
    mode = cfg["会后动作"]["模式"]
    if mode == "不动作":
        return 0
    h, m = map(int, cfg["开始时间"].split(":"))
    d = datetime.strptime(res["date"], "%Y-%m-%d")
    start = d.replace(hour=h, minute=m)
    end = start + timedelta(hours=int(cfg["时长小时"]), minutes=int(cfg["时长分钟"]))
    base = {
        "topic": cfg["主题"], "room": res["room"], "start": start.isoformat(), "end": end.isoformat(),
        "receiver": cfg["会后动作"].get("小鲁班ID", "p_xiaoluban"),
    }
    items = []
    if mode == "通知模式":
        due = start - timedelta(minutes=int(cfg["会后动作"].get("提醒提前分钟", 5)))
        items.append(dict(base, kind="notify", due=due.isoformat()))
    elif mode == "自动释放":
        items.append(dict(base, kind="release", due=start.isoformat()))
    with _lock:
        cur = _load()
        for it in items:
            it["id"] = uuid.uuid4().hex[:8]
            cur.append(it)
        _save(cur)
    return len(items)


def describe(a):
    st = datetime.fromisoformat(a["start"])
    what = "发提醒" if a["kind"] == "notify" else "取消会议、释放会议室"
    return f'{datetime.fromisoformat(a["due"]):%m/%d %H:%M} {what}｜{a["topic"]} {st:%m/%d %H:%M}｜{a["room"]}'


def remove(aid):
    with _lock:
        _save([a for a in _load() if a["id"] != aid])


def run_due(cfg, log):
    """执行所有到点的动作（在后台线程里调用）。"""
    now = datetime.now()
    with _lock:
        items = _load()
    override = cfg["高级"].get("welink-cli路径", "")
    for a in items:
        due = datetime.fromisoformat(a["due"])
        start = datetime.fromisoformat(a["start"])
        end = datetime.fromisoformat(a["end"])
        if due > now:
            continue
        ok = True
        try:
            if a["kind"] == "notify":
                if now > start + timedelta(minutes=10):
                    log(f"提醒已过时（会议 {start:%m/%d %H:%M} 早已开始），不再发送", "warn")
                else:
                    text = f'会议室提醒: {a["topic"]} {start:%Y-%m-%d} {start:%H:%M} 即将开始，会议室: {a["room"]}，请及时前往，避免被自动释放！'
                    welink.send(a["receiver"], text, override)
                    log(f"已发送会前提醒给 {a['receiver']}", "ok")
            else:
                if now > end:
                    log(f"会议 {start:%m/%d %H:%M} 已结束，不再释放", "warn")
                else:
                    mid = welink.find_meeting(a["topic"], start, end, override)
                    if not mid:
                        raise RuntimeError("在 WeLink 里没找到这场会")
                    welink.cancel(mid, override)
                    log(f"已取消会议 {mid}，会议室 {a['room']} 已释放", "ok")
        except Exception as e:
            ok = False
            log(f"会后动作失败：{e}", "bad")
            a["fails"] = a.get("fails", 0) + 1
        if ok or a.get("fails", 0) >= 3:
            remove(a["id"])
        else:
            with _lock:
                cur = _load()
                for c in cur:
                    if c["id"] == a["id"]:
                        c["fails"] = a["fails"]
                        c["due"] = (now + timedelta(minutes=1)).isoformat()
                _save(cur)
