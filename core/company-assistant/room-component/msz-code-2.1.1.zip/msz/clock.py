"""时间：按“服务器时钟”等到开放时刻。

本机时钟和 WeLink 服务器差几百毫秒到几秒很常见。旧版按本机时钟 12:00:00 点击，
本机慢 1 秒就晚 1 秒。这里用服务器响应头里的 Date 估出偏差：Date 只精确到秒，
所以连续请求，抓住它从 :xx 跳到 :xx+1 的那一刻，精度约等于一次请求往返时间。
"""
import http.client
import ssl
import time
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from urllib.parse import quote, urlparse


class Clock:
    def __init__(self):
        self.offset = 0.0  # 服务器时间 - 本机时间（秒）
        self.measured_at = None
        self.uncertainty = None

    def now(self):
        return datetime.now() + timedelta(seconds=self.offset)

    def describe(self):
        if self.measured_at is None:
            return "未校准（按本机时钟）"
        o = self.offset
        if abs(o) < 0.05:
            return "本机与服务器一致"
        return f"本机比服务器{'慢' if o > 0 else '快'} {abs(o):.2f} 秒，已按服务器时间修正"


def measure_offset(url, budget=4.0):
    """返回 (偏差秒, 误差秒)。失败时抛异常。"""
    u = urlparse(url)
    host, port = u.hostname, u.port
    if u.scheme == "https":
        conn = http.client.HTTPSConnection(host, port or 443, timeout=4, context=ssl._create_unverified_context())
    else:
        conn = http.client.HTTPConnection(host, port or 80, timeout=4)
    path = quote((u.path or "/") + (("?" + u.query) if u.query else ""), safe="/?=&%:+,;@-._~")
    prev = None
    end = time.time() + budget
    try:
        while time.time() < end:
            t0 = time.time()
            conn.request("HEAD", path)
            r = conn.getresponse()
            r.read()
            t1 = time.time()
            d = r.getheader("Date")
            if not d:
                raise RuntimeError("服务器响应里没有 Date 头")
            sec = parsedate_to_datetime(d).timestamp()
            mid = (t0 + t1) / 2
            if prev is not None and sec != prev[0]:
                # 服务器时间在 prev 与本次之间跨过了整秒 sec
                boundary_local = (prev[1] + mid) / 2
                return sec - boundary_local, (mid - prev[1]) / 2 + (t1 - t0) / 2
            prev = (sec, mid)
            time.sleep(0.02)
    finally:
        conn.close()
    raise RuntimeError("测量超时")


def wait_until(clock, target, stop_event, tick=None):
    """按 clock 等到 target（服务器时钟下的 datetime）。被停止返回 False。

    用短步长反复看时间，不做一次长 sleep：电脑睡眠唤醒、本机改时间后都能及时反应。
    """
    last_tick = 0
    while True:
        if stop_event.is_set():
            return False
        remain = (target - clock.now()).total_seconds()
        if remain <= 0:
            return True
        if tick and time.time() - last_tick >= 1:
            tick(remain)
            last_tick = time.time()
        if remain > 5:
            time.sleep(min(0.5, remain - 5))
        else:
            time.sleep(min(0.005, remain))
