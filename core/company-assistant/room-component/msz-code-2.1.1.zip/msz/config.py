"""配置、历史记录与路径。

兼容旧版：旧 config.json / booking_history.json 原样读入，旧字段一个不删，
新字段缺失时补默认值；browser_profile/ 目录沿用，换新版不用重新登录。
"""
import copy
import json
import os
import sys
import threading
from datetime import datetime

APP_NAME = "秘书终结者"
from .version import SHELL, VERSION  # noqa: E402,F401
DEFAULT_URL = "https://inner.welink.huawei.com/meetingroom/#/"


def app_dir():
    """数据目录：打包后是 exe 所在目录，源码运行时是项目根目录（可用环境变量覆盖，测试用）。"""
    env = os.environ.get("MSZ_HOME")
    if env:
        return env
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def path(*parts):
    return os.path.join(app_dir(), *parts)


DEFAULTS = {
    "主题": "日常会议",
    "开始时间": "14:00",
    "时长小时": 2,
    "时长分钟": 0,
    # 新装默认为空：每个人的楼栋不同，第一次用时在「抢订计划」里从页面读取或手动添加。
    # 旧版 config.json 里的「位置筛选」「优先会议室」原样保留。
    "优先会议室": [],
    # 目标日（下周同一天）是星期几时才抢；1=周一 … 7=周日。默认每天都抢，与旧版一致。
    "抢订日": [1, 2, 3, 4, 5, 6, 7],
    "抢订设置": {
        "开放时间": "12:00:00",
        "提前填表秒数": 60,
        "最大重试次数": 5,
        "重试间隔毫秒": 200,
        "抢不到换下一间": True,
        "登录预检提前分钟": 15,
        "校准服务器时间": True,
    },
    "会后动作": {"模式": "不动作", "小鲁班ID": "p_xiaoluban", "提醒提前分钟": 5},
    "系统": {"守护时阻止睡眠": True, "开机自动启动守护": False, "自动检查更新": True},
    "高级": {
        "网址": DEFAULT_URL,
        "浏览器": "自动",  # 自动 / Edge / Chrome / 内置Chromium
        "自动标定网格": True,
        "网格起点X": 472,
        "格子宽度": 30,
        "网格起始时间": "08:30",
        "welink-cli路径": "",
        # 以下两项界面不展示，只给测试脚本用
        "无界面": False,
        "等待倍率": 1.0,
    },
}

POST_MODES = ["不动作", "通知模式", "自动释放"]
_lock = threading.RLock()


def _merge(base, extra):
    out = copy.deepcopy(base)
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config():
    p = path("config.json")
    data = {}
    if os.path.exists(p):
        try:
            with open(p, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            # 文件损坏时留一份备份，不覆盖用户原文件
            bak = p + ".broken-" + datetime.now().strftime("%Y%m%d%H%M%S")
            try:
                os.replace(p, bak)
            except OSError:
                pass
            data = {}
    cfg = _merge(DEFAULTS, data)
    if cfg["会后动作"].get("模式") not in POST_MODES:
        cfg["会后动作"]["模式"] = "不动作"
    return cfg


def save_config(cfg):
    with _lock:
        p = path("config.json")
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=4)
        os.replace(tmp, p)


# ---------------- 历史记录 ----------------

def load_history():
    p = path("booking_history.json")
    if not os.path.exists(p):
        return []
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except Exception:
        return []


def add_history(date_str, time_desc, status, room, note=""):
    with _lock:
        hist = load_history()
        rec = {
            "日期": date_str,
            "时间": time_desc,
            "状态": status,
            "会议室": room,
            "时间戳": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        if note:
            rec["备注"] = note
        hist.append(rec)
        hist = hist[-50:]
        p = path("booking_history.json")
        tmp = p + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(hist, f, ensure_ascii=False, indent=2)
        os.replace(tmp, p)
        return rec


def time_desc(cfg):
    return f'{cfg["开始时间"]} 起 {int(cfg["时长小时"])}h{int(cfg["时长分钟"])}m'


def already_booked(date_str, cfg):
    """同一目标日、同一时段已经成功过就不再抢（防止重启后重复预定）。"""
    td = time_desc(cfg)
    return any(h.get("日期") == date_str and h.get("时间") == td and h.get("状态") == "成功" for h in load_history())
